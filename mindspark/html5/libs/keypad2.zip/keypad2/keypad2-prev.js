var cnt = 0;
var tablet = osDetection();
tablet = 1;
var tempo = new Array();
var tempo2 = new Array();
var firstTime = 1;
$(document).ready(function (e)
{
    $("head").append('<link type="text/css" href="../../../libs/keypad2/jquery.keypad.css" rel="stylesheet">');
    $("head").append('<script type="text/javascript" src="../../../libs/keypad2/jquery.keypad.js"></script>');
    $("head").append('<link type="text/css" href="../../../libs/keypad2/keypadCustomStyle.css" rel="stylesheet">');
    $("input").live("blur", function ()
    {
        var id = $(this).attr('id');
        if (in_array(id, tempo))
        {
            var index = tempo.indexOf(id);
            var index2 = tempo2.indexOf(id);
            //tempo.splice(index, 1);
            tempo2.splice(index2, 1);
        }
    });
    $("input[type=text]").live("focus click tap vclick", function ()
    {
        event.stopImmediatePropagation(); event.preventDefault();
        if (tablet)
        {
            var id = $(this).attr('id');
            //console.log(id);
            if (firstTime)
            {
                $.keypad.addKeyDef('FLIP', 'flip', function (inst)
                {
                    cnt++;
                    if (cnt % 2 != 0)
                    {
                        $(".keypad-popup").css({
                            'top': '-10px',
                            'left': '710px',
                            'width': '80px',
                            'height': '552px',
                            'float': 'right',
                            'padding-top': '40px'
                        });
                    }
                    else
                    {
                        $(".keypad-popup").css({
                            'top': '526px',
                            'left': '0px',
                            'width': '790px',
                            'height': '50px',
                            'float': 'left',
                            'padding-top': '5px'
                        });

                    }

                });
            }
            if (!in_array(id, tempo2))
            {
                tempo2.push(id);
                $("#" + id).keypad({
                    flipText: 'Flip',
                    flipStatus: 'Flip the keypad',
                    //changeText: 'Change',
                    //changeStatus: 'Change the keypad',
                    layout: ['1234', '567', '890', '-/.', $.keypad.ENTER + $.keypad.CLOSE + $.keypad.BACK + $.keypad.CLEAR + $.keypad.FLIP, /*, $.keypad.CHANGE*/],
                    keypadClass: 'midnightKeypad',
                    prompt: 'Enter values using this keypad.', closeText: 'X', clearText: 'Clear', backText: '&#8592;', enterText: '&#8629;',
                    //showOn: 'button',
                    onKeypress: function (key, value, inst)
                    {

                        var e = $.Event("keypress", { keyCode: key.charCodeAt(0) });
                        var e1 = $.Event("keyup", { keyCode: key.charCodeAt(0) });
                        var e2 = $.Event("keydown", { keyCode: key.charCodeAt(0) });
                        $("#" + id).trigger(e);
                        $("#" + id).trigger(e2);
                        $("#" + id).trigger(e1);
                        $("#" + id).val($("#" + id).val().replace(" ", ""));
                        console.log("--" + $("#" + id).val().replace(" ", "") + '---');
                    },
                    beforeShow: function (div, inst)
                    {
                        window.setTimeout(function ()
                        {

                            if (cnt % 2 != 0)
                            {
                                $(".keypad-popup").css({
                                    'top': '-10px',
                                    'left': '710px',
                                    'width': '80px',
                                    'height': '552px',
                                    'float': 'right',
                                    'padding-top': '40px'
                                });
                            }
                            else
                            {
                                $(".keypad-popup").css({
                                    'top': '526px',
                                    'left': '0px',
                                    'width': '790px',
                                    'height': '50px',
                                    'float': 'left',
                                    'padding-top': '5px'
                                });

                            }
                            $(".keypad-close").attr('id', 'closed');

                        }, 10);
                    },
                    showAnim: ''
                });
            }
            if (!in_array(id, tempo))
            {
                tempo.push(id);
                $(this).blur().select();
                $(this).focus().select();
                //alert();
                if (firstTime)
                {
                    firstTime = 0;
                    $(".keypad-popup").draggable(
                    {
                        'containment': '#container'
                    });
                }

            }
            else
            {
                $('.keypad-popup').show();
            }
        }

    });


});

function tabKeypad(className)
{

    if (osDetection())
    {
        //$("#"+className).keypad();
    }
}
function simulateKeyPress(character)
{
    jQuery.event.trigger({ type: 'keypress', which: character.charCodeAt(0) });
}