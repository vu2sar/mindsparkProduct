var cnt = 0;
var tablet = osDetection();
tablet = 1;
var activeInputElements = new Array();				
var activeInputElements2 = new Array();
var firstTime = 1;

$(document).ready(function (e)
{	
	//adding keyPad Styles scripts to the header
    $("head").append('<link type="text/css" href="../../../libs/keypad2/jquery.keypad.css" rel="stylesheet">');
    $("head").append('<script type="text/javascript" src="../../../libs/keypad2/jquery.keypad.js"></script>');
    $("head").append('<link type="text/css" href="../../../libs/keypad2/keypadCustomStyle.css" rel="stylesheet">');
   
   	//removing Elements that have lost focus
    $("input").live("blur", function ()
    {
        var id = this.id;
        if (in_array(id, activeInputElements))
        {
            var index = activeInputElements.indexOf(id);
            var index2 = activeInputElements2.indexOf(id);
            //activeInputElements.splice(index, 1);
            activeInputElements2.splice(index2, 1);
        }
    });
    
   	//binding all input Elements of type 'text' here
   	// click tap vclick
    $("input[type=text]").live("focus", function ()
    {
        event.stopImmediatePropagation(); 			//prevent other handlers from execution. prevents propogation in the bubbling phase
        event.preventDefault();
        if (tablet)
        {
            var id = this.id;
            if (firstTime)
            {
                $.keypad.addKeyDef('FLIP', 'flip', function (inst)
                {	
                    cnt++;
                    if (cnt % 2 != 0)
                    {	// why not have this css on sheets. anyways no issues
                        $(".keypad-popup").css({
                            'top': '-10px',
                            'left': '710px',
                            'width': '80px',
                            'height': '552px',
                            'float': 'right',
                            'padding-top': '40px'
                        });
                    }
                    else
                    {
                        $(".keypad-popup").css({
                            'top': '526px',
                            'left': '0px',
                            'width': '790px',
                            'height': '50px',
                            'float': 'left',
                            'padding-top': '5px'
                        });
                    }
                });
            }
            
            if (!in_array(id, activeInputElements2))
            {
                activeInputElements2.push(id);
                $("#" + id).keypad({
                    flipText: 'Flip',
                    flipStatus: 'Flip the keypad',
                    //changeText: 'Change',
                    //changeStatus: 'Change the keypad',
                    layout: ['1234', '567', '890', '-/.', $.keypad.ENTER + $.keypad.CLOSE + $.keypad.BACK + $.keypad.CLEAR + $.keypad.FLIP, /*, $.keypad.CHANGE*/],
                    keypadClass: 'midnightKeypad',
                    prompt: 'Enter values using this keypad.', closeText: 'X', clearText: 'Clear', backText: '&#8592;', enterText: '&#8629;',
                    //showOn: 'button',
                    onKeypress: function (key, value, inst)
                    {

                        var e = $.Event("keypress", { keyCode: key.charCodeAt(0) });
                        var e1 = $.Event("keyup", { keyCode: key.charCodeAt(0) });
                        var e2 = $.Event("keydown", { keyCode: key.charCodeAt(0) });
                        $("#" + id).trigger(e);
                        $("#" + id).trigger(e2);
                        $("#" + id).trigger(e1);
                        $("#" + id).val($("#" + id).val().replace(" ", ""));
                        console.log("--" + $("#" + id).val().replace(" ", "") + '---');
                    },
                    beforeShow: function (div, inst)
                    {
                        window.setTimeout(function ()
                        {

                            if (cnt % 2 != 0)
                            {
                                $(".keypad-popup").css({
                                    'top': '-10px',
                                    'left': '710px',
                                    'width': '80px',
                                    'height': '552px',
                                    'float': 'right',
                                    'padding-top': '40px'
                                });
                            }
                            else
                            {
                                $(".keypad-popup").css({
                                    'top': '526px',
                                    'left': '0px',
                                    'width': '790px',
                                    'height': '50px',
                                    'float': 'left',
                                    'padding-top': '5px'
                                });

                            }
                            $(".keypad-close").attr('id', 'closed');

                        }, 10);
                    },
                    showAnim: ''
                });
            }
            
            //adding the current element if not already added. If added just show the keypad
          /*  if (!in_array(id, activeInputElements))
            {
                activeInputElements.push(id);
                $(this).blur().select();
                $(this).focus().select();
                //alert();
                if (firstTime)
                {
                    firstTime = 0;
                    $(".keypad-popup").draggable(
                    {
                        'containment': '#container'
                    });
                }
            }
            else
            {*/
                $('.keypad-popup').show();
            //}
        }
    });
});

function tabKeypad(className)
{

    if (osDetection())
    {
        //$("#"+className).keypad();
    }
}

// simulates an artificial keypress event from key pad
function simulateKeyPress(character)
{
    jQuery.event.trigger({ type: 'keypress', which: character.charCodeAt(0) });
}