<style>
    .site-footer { padding: 0px;}
    .site-footer{ bottom: 0; width: 100%;background: #F0F0F0;opacity: 1}

</style>

<!-- <footer class="site-footer">
    <div class="text-center">
        <span><a href='#'>FAQs</a></span>
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer> -->
<footer class="site-footer">
    <div class="text-right">
        <p style="color:black;padding-right:20px;font-size:9px;paddng-bottom:0">Version 1.0</p>
    </div>
</footer>
    
    
    <!-- js placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="<?php echo base_url(); ?>theme/admin/fuelux/js/spinner.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>theme/admin/bootstrap-fileupload/bootstrap-fileupload.js"></script> 
    
    <script class="include" type="text/javascript" src="<?php echo base_url(); ?>theme/admin/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo base_url(); ?>theme/admin/js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url(); ?>theme/admin/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>theme/admin/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>theme/admin/js/jquery.tagsinput.js"></script>
    <script src="<?php echo base_url(); ?>theme/admin/js/ga.js"></script>
    
    
    <script src="<?php echo base_url(); ?>theme/admin/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
	
    <script src="<?php echo base_url(); ?>theme/admin/js/form-component.js"></script>    
    
    
    <script type="text/javascript" src="<?php echo base_url(); ?>theme/admin/data-tables/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>theme/admin/data-tables/DT_bootstrap.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>theme/admin/data-tables/dataTables.tableTools.min.js"></script>
    
    <script src="<?php echo base_url(); ?>theme/admin/js/owl.carousel.js" ></script>
    <script src="<?php echo base_url(); ?>theme/admin/js/jquery.customSelect.min.js" ></script>
    <script src="<?php echo base_url(); ?>theme/admin/js/respond.min.js" ></script>
           
    <script src="<?php echo base_url(); ?>theme/admin/js/draggable-portlet.js"></script>
    
    <!--common script for all pages-->
    <script src="<?php echo base_url(); ?>theme/admin/js/common-scripts.js"></script>
    <link href="<?php echo base_url(); ?>theme/css/common.css" rel="stylesheet">
    <script src="<?php echo base_url(); ?>theme/js/common.js"></script>
    
